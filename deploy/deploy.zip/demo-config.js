const DEMO_KEYWORDS = [
    {
        keyword: "chimney sweep pottstown pa",
        target: "chimney sweep pottstown pa wells & sons"
    },
    {
        keyword: "chimney sweeps west chester pa",
        target: "chimney sweeps west chester pa wells & sons"
    },
    {
        keyword: "commercial solar orange county",
        target: "commercial solar orange county rep solar"
    },
    {
        keyword: "dentistry for children scottsdale",
        target: "dentistry for children scottsdale palm valley pediatrics"
    },
    {
        keyword: "a meeting loveland co",
        target: "a meeting loveland co new life recovery"
    },
    {
        keyword: "rehab loveland co",
        target: "rehab loveland co new life recovery"
    },
    {
        keyword: "divorce lawyer orlando fl",
        target: "divorce lawyer orlando fl caplan & associates"
    },
    {
        keyword: "car accident lawyer miami fl",
        target: "car accident lawyer miami fl 1-800 ask gary"
    },
    {
        keyword: "fence companies in albuquerque",
        target: "fence companies in albuquerque amazing gates"
    },
    {
        keyword: "car accident lawyer columbia sc",
        target: "car accident lawyer columbia sc s chris davis"
    },
    {
        keyword: "air duct cleaning dallas",
        target: "air duct cleaning dallas airductcleanup.com"
    },
    {
        keyword: "divorce attorney charlotte",
        target: "divorce attorney charlotte n stallard & bellof plic"
    }
];
